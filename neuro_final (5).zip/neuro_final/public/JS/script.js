// --- 1. DADOS DO QUIZ ---
const quizData = [
  {
    "questionNumber": 1,
    "question": "O termo 'Neurodivergência' foi cunhado para descrever quais indivíduos?",
    "answerOptions": [
      { "text": "Apenas indivíduos com transtornos de humor.", "rationale": "Embora transtornos de humor possam coexistir, o termo 'neurodivergência' se refere a variações neurológicas específicas, como Autismo e TDAH.", "isCorrect": false },
      { "text": "Indivíduos cujo funcionamento neurológico difere significativamente do que é considerado 'neurotípico'.", "rationale": "Este termo abrange condições como Autismo, TDAH, Dislexia e outras.", "isCorrect": true },
      { "text": "Indivíduos com alto QI.", "rationale": "Neurodivergência não é sinônimo de QI elevado.", "isCorrect": false },
      { "text": "Pessoas com lesões cerebrais adquiridas.", "rationale": "O termo refere-se majoritariamente a variações do desenvolvimento neurológico.", "isCorrect": false }
    ]
  },
  {
    "questionNumber": 2,
    "question": "De acordo com o DSM-5, quais são os três subtipos de TDAH?",
    "answerOptions": [
      { "text": "Leve, Moderado e Grave.", "rationale": "Estes são especificadores de gravidade, não os subtipos.", "isCorrect": false },
      { "text": "Predominantemente Inatento, Predominantemente Hiperativo/Impulsivo e Combinado.", "rationale": "Classificação reconhecida pelo DSM-5.", "isCorrect": true },
      { "text": "Dissociativo, Emocional e Cognitivo.", "rationale": "Não são subtipos do DSM-5 para TDAH.", "isCorrect": false },
      { "text": "Motor, Sensorial e Comportamental.", "rationale": "Também não são as categorias oficiais.", "isCorrect": false }
    ]
  },
  {
    "questionNumber": 3,
    "question": "Qual estratégia é útil para pessoas com TDAH?",
    "answerOptions": [
      { "text": "Confiar apenas na memória sem anotações.", "rationale": "Confiar só na memória tende a dificultar a conclusão de tarefas.", "isCorrect": false },
      { "text": "Usar agendas, lembretes e dividir tarefas em pequenos passos.", "rationale": "São estratégias práticas frequentemente recomendadas.", "isCorrect": true },
      { "text": "Eliminar todas as pausas do dia.", "rationale": "Pausas são importantes para manter o foco e reduzir exaustão.", "isCorrect": false },
      { "text": "Multiplicar tarefas para aumentar pressão.", "rationale": "Geralmente piora a execução e o estresse.", "isCorrect": false }
    ]
  }
];

let currentQuestionIndex = 0;
let score = 0;

// elementos quiz
const modal = document.getElementById('quizModal');
const openBtn = document.getElementById('openQuizBtn');
const closeBtn = document.getElementById('closeQuizBtn');
const quizContainer = document.getElementById('quiz-container');

// curiosidade
const btnCuriosidade = document.getElementById("botaoCuriosidade");
const saidaCuriosidade = document.getElementById("curiosidadeTexto");
const curiosidades = [
  "Neurodiversidade reconhece que cérebros funcionam de formas diferentes — e isso é natural na população.",
  "Pessoas autistas podem preferir rotinas previsíveis; avisos antecipados de mudanças ajudam.",
  "No TDAH, dividir tarefas em etapas curtas aumenta a chance de conclusão.",
  "Ajustes sensoriais (luz, som, cheiros) podem reduzir sobrecarga e melhorar a participação.",
  "Checklists e lembretes visuais são úteis para TDAH e também para pessoas neurotípicas."
];
if (btnCuriosidade && saidaCuriosidade) {
  btnCuriosidade.addEventListener("click", () => {
    const i = Math.floor(Math.random() * curiosidades.length);
    saidaCuriosidade.textContent = curiosidades[i];
  });
}

// salvar pontuação no back-end
async function salvarPontuacaoNoServidor(userId, pontuacao) {
  try {
    const resposta = await fetch('/api/quiz/score', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, pontuacao })
    });
    if (!resposta.ok) console.warn('API respondeu com status', resposta.status);
    else console.log('Pontuação salva');
  } catch (erro) {
    console.warn('Erro ao salvar pontuação (demo):', erro);
  }
}

/* ========================= QUIZ FUNCTIONS ========================= */
function startQuiz() {
  currentQuestionIndex = 0;
  score = 0;
  const title = document.getElementById('quizTitle');
  if (title) title.textContent = 'Quiz de Conhecimento';
  renderQuestion(currentQuestionIndex);
}

function renderQuestion(index) {
  if (index >= quizData.length) {
    showResult();
    return;
  }
  const questionObj = quizData[index];
  let htmlContent = `
    <div class="question-header">
      <h3>Questão ${questionObj.questionNumber} de ${quizData.length}</h3>
      <p class="score-display">Pontuação: ${score}</p>
    </div>
    <h4>${questionObj.question}</h4>
    <div class="options-list">
  `;
  questionObj.answerOptions.forEach((option, optionIndex) => {
    htmlContent += `<button class="option-button" data-index="${optionIndex}">${option.text}</button>`;
  });
  htmlContent += `</div><div id="feedback-${index}" class="feedback-area"></div>`;
  quizContainer.innerHTML = htmlContent;
  attachOptionListeners(index);
}

function attachOptionListeners(questionIndex) {
  const optionButtons = quizContainer.querySelectorAll('.option-button');
  optionButtons.forEach(button => {
    button.addEventListener('click', (event) => {
      const selectedOptionIndex = parseInt(event.currentTarget.dataset.index, 10);
      checkAnswer(selectedOptionIndex, questionIndex);
    }, { once: true });
  });
}

function checkAnswer(selectedIndex, questionIndex) {
  const questionObj = quizData[questionIndex];
  const selectedOption = questionObj.answerOptions[selectedIndex];
  const feedbackArea = document.getElementById(`feedback-${questionIndex}`);
  const optionButtons = quizContainer.querySelectorAll('.option-button');

  optionButtons.forEach(button => { button.disabled = true; });

  if (selectedOption.isCorrect) {
    score++;
    optionButtons[selectedIndex].classList.add('correct');
    feedbackArea.innerHTML = `<p class="correct-feedback">✅ Correto! Você acertou.</p>`;
  } else {
    optionButtons[selectedIndex].classList.add('incorrect');
    feedbackArea.innerHTML = `<p class="incorrect-feedback">❌ Incorreto.</p>`;
    const correctIndex = questionObj.answerOptions.findIndex(opt => opt.isCorrect);
    if (correctIndex !== -1) optionButtons[correctIndex].classList.add('correct-answer');
  }

  const scoreDisplay = quizContainer.querySelector('.score-display');
  if (scoreDisplay) scoreDisplay.textContent = `Pontuação: ${score}`;

  feedbackArea.innerHTML += `<p class="rationale-text">💡 <strong>Racional:</strong> ${selectedOption.rationale}</p>`;

  const nextButton = document.createElement('button');
  nextButton.textContent = "Próxima Questão »";
  nextButton.className = "quiz-next-button";
  nextButton.onclick = () => { currentQuestionIndex++; renderQuestion(currentQuestionIndex); };
  feedbackArea.appendChild(nextButton);
  nextButton.focus();
}

function showResult() {
  const percentage = (score / quizData.length) * 100;
  let resultMessage = '';
  if (percentage >= 80) resultMessage = "Parabéns! Excelente conhecimento sobre Neurodivergências.";
  else if (percentage >= 50) resultMessage = "Bom trabalho! Você demonstrou uma base sólida de conhecimento.";
  else resultMessage = "Continue explorando! Há muito o que aprender sobre Autismo e TDAH. Tente novamente!";

  const storedUserId = localStorage.getItem('userId');
  if (storedUserId) {
    salvarPontuacaoNoServidor(parseInt(storedUserId, 10), score);
    carregarLeaderboard();
  } else {
    console.warn('Usuário não logado; pontuação não será salva no banco.');
  }

  quizContainer.innerHTML = `
    <div class="result-box">
      <h4>🎉 QUIZ CONCLUÍDO! 🎉</h4>
      <p>Sua pontuação final é:</p>
      <p class="final-score">${score} de ${quizData.length}</p>
      <p class="final-message">${resultMessage}</p>
      <button class="quiz-next-button" id="tryAgainBtn">Tentar Novamente</button>
      <button class="quiz-next-button" id="closeResultBtn">Fechar</button>
    </div>
  `;
  const tryAgainBtn = document.getElementById('tryAgainBtn');
  const closeResultBtn = document.getElementById('closeResultBtn');
  if (tryAgainBtn) tryAgainBtn.onclick = startQuiz;
  if (closeResultBtn) closeResultBtn.onclick = () => { closeModal(); };
}

/* ========================= MODAIS: QUIZ ========================= */
let lastFocusedElementBeforeModal = null;
function openModal() {
  lastFocusedElementBeforeModal = document.activeElement;
  modal.setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden';
  if (openBtn) openBtn.setAttribute('aria-expanded', 'true');
  const focusable = modal.querySelectorAll('button, [href], input, textarea, select, [tabindex]:not([tabindex="-1"])');
  if (focusable.length) focusable[0].focus();
  document.addEventListener('focus', trapFocus, true);
}
function closeModal() {
  modal.setAttribute('aria-hidden', 'true');
  document.body.style.overflow = '';
  if (openBtn) openBtn.setAttribute('aria-expanded', 'false');
  document.removeEventListener('focus', trapFocus, true);
  if (lastFocusedElementBeforeModal && typeof lastFocusedElementBeforeModal.focus === 'function') lastFocusedElementBeforeModal.focus();
}
function trapFocus(event) {
  if (!modal.contains(event.target)) {
    event.stopPropagation();
    const focusable = modal.querySelectorAll('button, [href], input, textarea, select, [tabindex]:not([tabindex="-1"])');
    if (focusable.length) focusable[0].focus();
  }
}

/* ========================= TEMA ESCURO ========================= */
const themeToggleBtn = document.getElementById('themeToggleBtn');
function applySavedTheme() {
  const saved = localStorage.getItem("theme");
  if (saved === "dark") {
    document.documentElement.classList.add("dark");
    if (themeToggleBtn) themeToggleBtn.setAttribute('aria-pressed', 'true');
  } else {
    document.documentElement.classList.remove("dark");
    if (themeToggleBtn) themeToggleBtn.setAttribute('aria-pressed', 'false');
  }
}
function toggleDark() {
  document.documentElement.classList.toggle("dark");
  const isDark = document.documentElement.classList.contains("dark");
  localStorage.setItem("theme", isDark ? "dark" : "light");
  if (themeToggleBtn) themeToggleBtn.setAttribute('aria-pressed', isDark ? 'true' : 'false');
}
if (themeToggleBtn) themeToggleBtn.addEventListener('click', toggleDark);
applySavedTheme();

/* ========================= LOGIN / SIGNUP HANDLERS ========================= */
const openLoginBtn = document.getElementById('openLoginBtn');
const loginModal = document.getElementById('loginModal');
const closeLoginBtn = document.getElementById('closeLoginBtn');
const cancelLoginBtn = document.getElementById('cancelLoginBtn');
const loginForm = document.getElementById('loginForm');
const loginFeedback = document.getElementById('loginFeedback');
const submitLoginBtn = document.getElementById('submitLoginBtn');

const signupModal = document.getElementById('signupModal');
const openSignupFromLogin = document.getElementById('openSignupFromLogin');
const closeSignupBtn = document.getElementById('closeSignupBtn');
const cancelSignupBtn = document.getElementById('cancelSignupBtn');
const signupForm = document.getElementById('signupForm');
const signupFeedback = document.getElementById('signupFeedback');
const submitSignupBtn = document.getElementById('submitSignupBtn');

// novos elementos de UI de usuário e placar
const userStatus = document.getElementById('userStatus');
const logoutBtn = document.getElementById('logoutBtn');
const leaderboardPanel = document.getElementById('leaderboardPanel');
const leaderboardList = document.getElementById('leaderboardList');
const leaderboardToggle = document.getElementById('leaderboardToggle');

let lastFocusedBeforeLogin = null;

function updateUserUI() {
  const name = localStorage.getItem('userName');
  if (name) {
    if (userStatus) userStatus.textContent = `Olá, ${name}`;
    if (logoutBtn) logoutBtn.style.display = 'inline-flex';
    if (openLoginBtn) openLoginBtn.style.display = 'none';
  } else {
    if (userStatus) userStatus.textContent = '';
    if (logoutBtn) logoutBtn.style.display = 'none';
    if (openLoginBtn) openLoginBtn.style.display = 'inline-flex';
  }
}

if (logoutBtn) {
  logoutBtn.addEventListener('click', () => {
    localStorage.removeItem('userId');
    localStorage.removeItem('userName');
    localStorage.removeItem('authToken');
    updateUserUI();
  });
}

function openLoginModal() {
  lastFocusedBeforeLogin = document.activeElement;
  loginModal.setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden';
  if (openLoginBtn) openLoginBtn.setAttribute('aria-expanded', 'true');
  const first = loginModal.querySelector('input[name="email"]');
  if (first) first.focus();
  activateFocusTrap(loginModal);
}
function closeLoginModal() {
  loginModal.setAttribute('aria-hidden', 'true');
  document.body.style.overflow = '';
  if (openLoginBtn) openLoginBtn.setAttribute('aria-expanded', 'false');
  deactivateFocusTrap();
  if (lastFocusedBeforeLogin && typeof lastFocusedBeforeLogin.focus === 'function') lastFocusedBeforeLogin.focus();
  if (loginForm) loginForm.reset();
  if (loginFeedback) loginFeedback.textContent = '';
  clearFieldErrors();
}

function clearFieldErrors() {
  const e = document.getElementById('emailError'); if (e) e.textContent = '';
  const p = document.getElementById('passwordError'); if (p) p.textContent = '';
}
function validateLoginForm() {
  clearFieldErrors();
  let ok = true;
  const email = document.getElementById('loginEmail');
  const pass = document.getElementById('loginPassword');
  if (!email || !pass) return false;
  if (!email.value || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) {
    document.getElementById('emailError').textContent = 'Digite um email válido.';
    ok = false;
  }
  if (!pass.value || pass.value.length < 6) {
    document.getElementById('passwordError').textContent = 'Senha com pelo menos 6 caracteres.';
    ok = false;
  }
  return ok;
}

// LOGIN REAL
async function fakeLoginRequest(email, password) {
  try {
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });

    const data = await response.json();

    if (!response.ok) {
      return { ok: false, message: data.error || 'Erro ao fazer login.' };
    }

    if (data.user) {
      localStorage.setItem('userId', String(data.user.id));
      localStorage.setItem('userName', data.user.name || 'Usuário');
    }
    if (data.token) {
      localStorage.setItem('authToken', data.token);
    }

    return {
      ok: true,
      name: data.user ? data.user.name : 'Usuário',
      token: data.token || null
    };
  } catch (err) {
    console.error(err);
    return { ok: false, message: 'Erro de rede. Tente novamente.' };
  }
}

if (loginForm) {
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!validateLoginForm()) return;
    const email = document.getElementById('loginEmail').value.trim();
    const password = document.getElementById('loginPassword').value;
    if (submitLoginBtn) submitLoginBtn.disabled = true;
    if (loginFeedback) loginFeedback.textContent = 'Entrando...';
    try {
      const res = await fakeLoginRequest(email, password);
      if (res.ok) {
        if (loginFeedback) loginFeedback.textContent = `Bem-vindo, ${res.name}!`;
        updateUserUI();
        setTimeout(() => closeLoginModal(), 700);
      } else {
        if (loginFeedback) loginFeedback.textContent = res.message || 'Erro ao autenticar.';
      }
    } catch (err) {
      console.error(err); if (loginFeedback) loginFeedback.textContent = 'Erro de rede. Tente novamente.';
    } finally { if (submitLoginBtn) submitLoginBtn.disabled = false; }
  });
}

/* SIGNUP */
function openSignupModal() {
  signupModal.setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden';
  activateFocusTrap(signupModal);
  const first = signupModal.querySelector('input[name="name"]');
  if (first) first.focus();
}
function closeSignupModal() {
  signupModal.setAttribute('aria-hidden', 'true');
  document.body.style.overflow = '';
  deactivateFocusTrap();
  if (loginForm) loginForm.reset();
  if (signupForm) signupForm.reset();
  if (signupFeedback) signupFeedback.textContent = '';
  clearSignupErrors();
}

function clearSignupErrors() {
  const n = document.getElementById('nameError'); if (n) n.textContent = '';
  const e = document.getElementById('signupEmailError'); if (e) e.textContent = '';
  const p = document.getElementById('signupPasswordError'); if (p) p.textContent = '';
  const c = document.getElementById('signupConfirmError'); if (c) c.textContent = '';
}
function validateSignupForm() {
  clearSignupErrors();
  let ok = true;
  const name = document.getElementById('signupName');
  const email = document.getElementById('signupEmail');
  const pass = document.getElementById('signupPassword');
  const confirm = document.getElementById('signupConfirm');
  if (!name || !email || !pass || !confirm) return false;
  if (!name.value || name.value.trim().length < 2) { document.getElementById('nameError').textContent = 'Digite seu nome.'; ok = false; }
  if (!email.value || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) { document.getElementById('signupEmailError').textContent = 'Email inválido.'; ok = false; }
  if (!pass.value || pass.value.length < 6) { document.getElementById('signupPasswordError').textContent = 'Senha com pelo menos 6 caracteres.'; ok = false; }
  if (pass.value !== confirm.value) { document.getElementById('signupConfirmError').textContent = 'As senhas não coincidem.'; ok = false; }
  return ok;
}

async function fakeSignupRequest(body) {
  try {
    const response = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });

    const data = await response.json();

    if (!response.ok) {
      return { ok: false, message: data.error || 'Erro ao criar conta.' };
    }

    if (data.user) {
      localStorage.setItem('userId', String(data.user.id));
      localStorage.setItem('userName', data.user.name || 'Usuário');
    }

    return { ok: true, user: data.user };
  } catch (err) {
    console.error(err);
    return { ok: false, message: 'Erro de rede. Tente novamente.' };
  }
}

if (signupForm) {
  signupForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!validateSignupForm()) return;
    const name = document.getElementById('signupName').value.trim();
    const email = document.getElementById('signupEmail').value.trim();
    const password = document.getElementById('signupPassword').value;
    if (submitSignupBtn) submitSignupBtn.disabled = true;
    if (signupFeedback) signupFeedback.textContent = 'Criando conta...';
    try {
      const res = await fakeSignupRequest({ name, email, password });
      if (res.ok) {
        if (signupFeedback) signupFeedback.textContent = `Conta criada! Bem-vindo, ${res.user.name}.`;
        updateUserUI();
        setTimeout(() => closeSignupModal(), 900);
      } else {
        if (signupFeedback) signupFeedback.textContent = res.message || 'Erro ao criar conta.';
      }
    } catch (err) {
      console.error(err); if (signupFeedback) signupFeedback.textContent = 'Erro de rede. Tente novamente.';
    } finally { if (submitSignupBtn) submitSignupBtn.disabled = false; }
  });
}

/* cancelar / botões */
if (openLoginBtn) openLoginBtn.addEventListener('click', () => openLoginModal());
if (closeLoginBtn) closeLoginBtn.addEventListener('click', () => closeLoginModal());
if (cancelLoginBtn) cancelLoginBtn.addEventListener('click', () => closeLoginModal());
if (openSignupFromLogin) openSignupFromLogin.addEventListener('click', () => { closeLoginModal(); setTimeout(openSignupModal, 160); });
if (closeSignupBtn) closeSignupBtn.addEventListener('click', () => closeSignupModal());
if (cancelSignupBtn) cancelSignupBtn.addEventListener('click', () => closeSignupModal());
window.addEventListener('click', (e) => { if (e.target === loginModal) closeLoginModal(); if (e.target === signupModal) closeSignupModal(); });
window.addEventListener('keydown', (e) => { if (e.key === 'Escape') { if (loginModal.getAttribute('aria-hidden') === 'false') closeLoginModal(); if (signupModal.getAttribute('aria-hidden') === 'false') closeSignupModal(); } });

/* ===== Focus trap genérico ===== */
let currentTrappedModal = null;
function activateFocusTrap(modalEl) {
  currentTrappedModal = modalEl;
  document.addEventListener('focus', enforceFocus, true);
}
function deactivateFocusTrap() {
  document.removeEventListener('focus', enforceFocus, true);
  currentTrappedModal = null;
}
function enforceFocus(event) {
  if (!currentTrappedModal) return;
  if (!currentTrappedModal.contains(event.target)) {
    event.stopPropagation();
    const focusable = currentTrappedModal.querySelectorAll('button, [href], input, textarea, select, [tabindex]:not([tabindex="-1"])');
    if (focusable.length) focusable[0].focus();
  }
}

/* ====== LEADERBOARD ====== */
async function carregarLeaderboard() {
  if (!leaderboardList) return;
  try {
    const resp = await fetch('/api/quiz/leaderboard');
    if (!resp.ok) throw new Error('Resposta não OK');
    const data = await resp.json();

    if (!Array.isArray(data) || data.length === 0) {
      leaderboardList.innerHTML = '<li>Ninguém jogou ainda 👀</li>';
      return;
    }

    leaderboardList.innerHTML = data.map((row, index) => `
      <li>
        <span class="lb-pos">${index + 1}º</span>
        <span class="lb-name">${row.name}</span>
        <span class="lb-score">${row.best_score} pts</span>
      </li>
    `).join('');
  } catch (e) {
    console.error(e);
    leaderboardList.innerHTML = '<li>Erro ao carregar placar</li>';
  }
}

if (leaderboardToggle && leaderboardPanel) {
  leaderboardToggle.addEventListener('click', () => {
    leaderboardPanel.classList.toggle('minimized');
    leaderboardToggle.textContent = leaderboardPanel.classList.contains('minimized') ? '+' : '−';
  });
}

/* ========================= EVENTOS GLOBAIS QUIZ ========================= */
if (openBtn) {
  openBtn.addEventListener('click', () => {
    openModal();
    startQuiz();
  });
}
if (closeBtn) {
  closeBtn.addEventListener('click', () => {
    closeModal();
  });
}
window.addEventListener('click', (event) => { if (event.target === modal) closeModal(); });
window.addEventListener('keydown', (e) => { if (e.key === 'Escape' && modal.getAttribute('aria-hidden') === 'false') closeModal(); });

carregarLeaderboard();
updateUserUI();
