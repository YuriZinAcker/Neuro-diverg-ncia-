// db.js
const mysql = require('mysql2/promise');

// Conexão com o MySQL
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'omega3',
  database: 'neurodivergencias'
});

module.exports = pool;
