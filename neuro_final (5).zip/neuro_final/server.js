const express = require('express');
const path = require('path');
const bcrypt = require('bcryptjs');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// rota principal
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// teste de conexão
app.get('/api/test-db', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT 1 AS ok');
    res.json({ ok: true, db: rows });
  } catch (error) {
    console.error('Erro ao conectar no MySQL:', error.message);
    res.status(500).json({ ok: false, error: 'Falha ao conectar no banco' });
  }
});

/* ==================== AUTENTICAÇÃO ==================== */

// cadastro
app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Preencha nome, email e senha.' });
    }

    const [exists] = await db.query(
      'SELECT id FROM users WHERE email = ?',
      [email]
    );
    if (exists.length > 0) {
      return res.status(400).json({ error: 'Email já cadastrado.' });
    }

    const hash = await bcrypt.hash(password, 10);

    const [result] = await db.query(
      'INSERT INTO users (nome, email, senha_hash) VALUES (?, ?, ?)',
      [name, email, hash]
    );

    return res.json({
      message: 'Usuário cadastrado com sucesso!',
      user: { id: result.insertId, name, email }
    });
  } catch (error) {
    console.error('Erro no cadastro:', error.message);
    res.status(500).json({ error: 'Erro ao cadastrar.' });
  }
});

// login
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    const [rows] = await db.query(
      'SELECT * FROM users WHERE email = ?',
      [email]
    );
    if (rows.length === 0) {
      return res.status(400).json({ error: 'Usuário não encontrado.' });
    }

    const user = rows[0];
    const ok = await bcrypt.compare(password, user.senha_hash);

    if (!ok) {
      return res.status(400).json({ error: 'Senha incorreta.' });
    }

    return res.json({
      message: 'Login realizado!',
      user: {
        id: user.id,
        name: user.nome,
        email: user.email
      },
      token: 'token-local'
    });
  } catch (error) {
    console.error('Erro no login:', error.message);
    res.status(500).json({ error: 'Erro no login.' });
  }
});

/* ==================== QUIZ ==================== */

app.post('/api/quiz/score', async (req, res) => {
  try {
    const { userId, pontuacao } = req.body;

    if (!userId || pontuacao === undefined) {
      return res.status(400).json({
        error: 'Envie userId e pontuacao no corpo da requisição.'
      });
    }

    const [result] = await db.query(
      'INSERT INTO quiz_scores (user_id, pontuacao) VALUES (?, ?)',
      [userId, pontuacao]
    );

    return res.status(201).json({
      message: 'Pontuação salva com sucesso!',
      scoreId: result.insertId
    });
  } catch (error) {
    console.error('Erro ao salvar pontuação do quiz:', error.message);
    return res.status(500).json({ error: 'Erro ao salvar pontuação.' });
  }
});

app.get('/api/quiz/score/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const [rows] = await db.query(
      'SELECT pontuacao, respondido_em FROM quiz_scores WHERE user_id = ? ORDER BY respondido_em DESC',
      [userId]
    );
    res.json(rows);
  } catch (error) {
    console.error('Erro ao buscar pontuações:', error.message);
    res.status(500).json({ error: 'Erro ao buscar pontuações.' });
  }
});

app.get('/api/quiz/leaderboard', async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT u.nome, MAX(q.pontuacao) AS best_score
       FROM quiz_scores q
       JOIN users u ON u.id = q.user_id
       GROUP BY u.id
       ORDER BY best_score DESC
       LIMIT 10`
    );
    res.json(rows);
  } catch (error) {
    console.error('Erro ao carregar leaderboard:', error.message);
    res.status(500).json({ error: 'Erro ao carregar leaderboard.' });
  }
});

app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
