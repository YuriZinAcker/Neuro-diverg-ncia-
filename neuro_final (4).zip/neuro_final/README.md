# Portal de Notícias - Node.js + Express

![Node](https://img.shields.io/badge/Node-18%2B-brightgreen?style=flat&logo=node.js)
![License](https://img.shields.io/badge/License-MIT-blue?style=flat)
![MySQL](https://img.shields.io/badge/MySQL-8.0-orange?style=flat&logo=mysql)
 
[![Open in Codespaces](https://img.shields.io/badge/Open%20in-Codespaces-24292f?style=flat&logo=github&logoColor=white)](https://github.com/YuriZinAcker)
[![Dev Containers](https://img.shields.io/badge/Dev%20Containers-0078D4?style=flat&logo=visual-studio-code&logoColor=white)](https://code.visualstudio.com/docs/devcontainers/containers)

Quick actions: use the **Codespaces** badge to create a codespace for this repo, or read the **Dev Containers** docs to open the project in a VS Code Dev Container.

Um portal de notícias didático construído com Node.js, Express, EJS e MySQL, com foco em aprendizado de back-end, MVC e boas práticas de organização. Este README descreve a estrutura do projeto, requisitos, como configurar e executar o projeto em diferentes ambientes.

## Índice

- Sobre o projeto
- Tecnologias e versões
- Estrutura de pastas
- Requisitos
- Como clonar e configurar
  - Opção 1: Ambiente local
  - Opção 2: Dev Container (VS Code)
  - Opção 3: GitHub Codespaces
- Inicialização (seed)
- Rodando a aplicação
- Rotas principais
- Banco de dados (resumo)
- Troubleshooting
- Comandos úteis
- Contribuindo

---

## Sobre o projeto

Este é um portal de notícias simplificado com área pública e área administrativa (CRUD de notícias). Foi criado com finalidade didática para demonstrar:

- Configuração de um projeto Node.js + Express
- Separação em camadas (rotas, controllers, models)
- Uso de templates EJS
- Acesso a banco MySQL via `mysql2`
- Boas práticas de organização e uso de variáveis de ambiente

Funcionalidades principais:

- Listagem pública de notícias
- Visualização de notícia por slug
- Área administrativa com:
  - Login de usuário
  - Cadastro, edição e exclusão de categorias
  - Cadastro, edição e exclusão de notícias

---

## Tecnologias e versões

- **Node.js**: 18+
- **Express**: 4+
- **EJS**: templates server-side
- **MySQL**: 8.x
- **mysql2/promise**: driver de conexão
- **dotenv**: variáveis de ambiente
- **express-session**: sessões de usuário
- **bcrypt**: hash de senha
- **nodemon** (dev): reload automático em desenvolvimento

Outros recursos opcionais:

- Docker / Dev Container
- GitHub Codespaces

---

## Estrutura de pastas

Estrutura geral do projeto:

- `app.js` — arquivo principal e configuração de rotas/middleware
- `package.json` — scripts e dependências
- `.env.example` — exemplo de variáveis de ambiente
- `config/db.js` — pool de conexões MySQL (`mysql2/promise`)
- `scripts/seed.js` — cria tabelas e dados iniciais
- `routes/` — rotas públicas e admin
- `controllers/` — lógica de negócio
- `models/` — camadas de acesso a dados (queries)
- `views/` — templates EJS (partials e páginas)
- `public/` — assets estáticos (CSS/JS)

Exemplo (simplificado):

```bash
portal-noticias-express/
├── app.js
├── package.json
├── .env.example
├── config/
│   └── db.js
├── scripts/
│   └── seed.js
├── routes/
│   ├── indexRoutes.js
│   ├── noticiasRoutes.js
│   └── adminRoutes.js
├── controllers/
│   ├── AuthController.js
│   ├── NoticiasController.js
│   └── CategoriasController.js
├── models/
│   ├── UsuarioModel.js
│   ├── NoticiaModel.js
│   └── CategoriaModel.js
├── views/
│   ├── partials/
│   ├── public/
│   └── admin/
└── public/
    ├── css/
    └── js/
```

---

## Requisitos

- Node.js 18+ instalado
- MySQL 8.x instalado e rodando
- Opcional:
  - Docker
  - VS Code com extensão **Dev Containers**
  - GitHub Codespaces habilitado

---

## Como clonar e configurar

### Clonar o repositório

```bash
git clone https://github.com/YuriZinAcker
cd portal-noticias-express
```

### Instalar dependências

```bash
npm install
```

---

## Opção 1: Ambiente local (sem Docker)

### 1. Configurar banco MySQL

Crie um banco (por exemplo `portal_noticias`) e um usuário com permissões apropriadas.

```sql
CREATE DATABASE portal_noticias;
CREATE USER 'portal_user'@'localhost' IDENTIFIED BY 'sua_senha';
GRANT ALL PRIVILEGES ON portal_noticias.* TO 'portal_user'@'localhost';
FLUSH PRIVILEGES;
```

### 2. Configurar `.env`

Use o `.env.example` como base:

```env
DB_HOST=localhost
DB_PORT=3306
DB_USER=portal_user
DB_PASSWORD=sua_senha
DB_NAME=portal_noticias

SESSION_SECRET=uma_chave_segura
NODE_ENV=development
PORT=3000
```

### 3. Rodar seed (criar tabelas e dados iniciais)

```bash
npm run seed
```

Isso executará `scripts/seed.js`, que:

- Cria as tabelas `usuarios`, `categorias`, `noticias` (se não existirem)
- Insere um usuário admin padrão e algumas categorias/notícias exemplo

Usuário admin padrão (exemplo):

- Email: `admin@example.com`
- Senha: `admin123`

### 4. Rodar o servidor

Modo desenvolvimento (com nodemon):

```bash
npm run dev
```

Modo normal:

```bash
npm start
```

Acesse em:

```text
http://localhost:3000
```

---

## Opção 2: Dev Container (VS Code)

Pré-requisitos:

- Docker instalado e rodando
- VS Code
- Extensão “Dev Containers”

Passos:

1. Abra a pasta do repositório no VS Code
2. Se o projeto possuir `.devcontainer/`:
   - Vá em **View > Command Palette…**
   - Busque por `Dev Containers: Reopen in Container`
3. Aguarde a criação do container
4. Dentro do Dev Container:
   - Rode `npm install`
   - Configure `.env` (ou use `.env.example`)
   - Rode `npm run seed`
   - Depois `npm run dev`

Se você estiver usando um `docker-compose.yml` de banco de dados junto do Dev Container, verifique se o host do banco está definido corretamente (`DB_HOST=db`, por exemplo).

---

## Opção 3: GitHub Codespaces

1. Clique no badge **Open in Codespaces** no topo do README
2. Selecione as opções de criação do Codespace (branch, tamanho de máquina)
3. Após subir o ambiente:
   - Abra um terminal no Codespaces
   - Rode `npm install`
   - Configure `.env` (pode copiar de `.env.example`)
   - Rode `npm run seed`
   - Em seguida, `npm run dev`

Se o projeto estiver configurado com portas encaminhadas, o Codespaces oferecerá um URL público para acessar o app.

---

## Banco de dados (resumo)

O projeto utiliza MySQL para persistência de dados, com as tabelas principais:

- `usuarios`
- `categorias`
- `noticias`

### config/db.js

Exemplo (simplificado):

```js
import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

const pool = mysql.createPool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME || 'portal_noticias',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

export default pool;
```

### scripts/seed.js

Responsável por:

- Criar as tabelas (se não existirem)
- Inserir dados iniciais (usuário admin, categorias, notícias exemplo)

Exemplo (trecho):

```js
import pool from '../config/db.js';
import bcrypt from 'bcrypt';

async function runSeed() {
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    await connection.query(`
      CREATE TABLE IF NOT EXISTS usuarios (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nome VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL UNIQUE,
        senha_hash VARCHAR(255) NOT NULL,
        is_admin TINYINT(1) DEFAULT 0
      )
    `);

    // demais tabelas (categorias, noticias)...

    const senhaHash = await bcrypt.hash('admin123', 10);
    await connection.query(
      `INSERT IGNORE INTO usuarios (nome, email, senha_hash, is_admin)
       VALUES ('Admin', 'admin@example.com', ?, 1)`,
      [senhaHash]
    );

    await connection.commit();
    console.log('Seed concluído com sucesso!');
  } catch (err) {
    await connection.rollback();
    console.error('Erro no seed:', err);
  } finally {
    connection.release();
  }
}

runSeed().then(() => process.exit());
```

---

## Sessão e autenticação (visão geral)

O projeto utiliza `express-session` para armazenar informações do usuário logado, com sessões baseadas em cookies.

- Ao logar, o usuário é salvo em `req.session.usuario`
- Rotas administrativas utilizam middleware para verificar se há usuário logado e se possui perfil admin

Exemplo de middleware:

```js
function verificaLogin(req, res, next) {
  if (!req.session || !req.session.usuario) {
    return res.redirect('/login');
  }
  next();
}

function verificaAdmin(req, res, next) {
  if (!req.session || !req.session.usuario || !req.session.usuario.is_admin) {
    return res.status(403).send('Acesso negado');
  }
  next();
}

export { verificaLogin, verificaAdmin };
```

---

## Rotas principais

Rotas públicas:

- `GET /` — listagem pública de notícias
- `GET /noticias/:slug` — página de notícia por slug
- `GET /login` — página de login
- `POST /login` — autenticação

Rotas administrativas (exemplos):

- `GET /admin` — dashboard administrativa
- `GET /admin/noticias` — listagem de notícias (admin)
- `GET /admin/noticias/nova` — formulário de nova notícia
- `POST /admin/noticias` — criação de notícia
- `GET /admin/noticias/:id/editar` — edição de notícia
- `POST /admin/noticias/:id` — atualização de notícia
- `POST /admin/noticias/:id/deletar` — exclusão de notícia

Rotas de categorias podem ser análogas:

- `GET /admin/categorias`
- `POST /admin/categorias`
- etc.

---

## Troubleshooting

Alguns problemas comuns e sugestões:

- Erro de conexão com o banco:
  - Verifique se o MySQL está rodando
  - Confira host/porta/usuário/senha em `.env`
- Seed não roda:
  - Verifique se o banco existe e se o usuário tem permissão
  - Confira se `scripts/seed.js` está apontando para o mesmo `DB_NAME` do `.env`
- Sessões não funcionam:
  - Verifique se `SESSION_SECRET` está definido
  - Confira se o middleware de sessão (`express-session`) está sendo registrado antes das rotas

Dica: quando rodar dentro de Codespaces com uma stack Dockerizada, verifique a configuração do ambiente e defina `DB_HOST=db` no `.env` se necessário.

---

## Inicialização (seed)

Este projeto não usa um sistema ORM com migrations; em vez disso, o arquivo `scripts/seed.js` é responsável por criar as tabelas e inserir dados iniciais. Rode o seed sempre que quiser recriar a base em um banco vazio ou rode manualmente os scripts SQL desejados.

Comandos úteis:

- `npm run seed` — cria as tabelas `usuarios`, `categorias`, `noticias` e insere dados de exemplo

## Rodando a aplicação

- Desenvolvimento: `npm run dev` (nodemon)
- Produção: `npm start`

## Rotas principais

Rotas públicas:

- `GET /` — listagem pública de notícias
- `GET /noticias/:slug` — visualização de uma notícia específica
- `GET /login` — página de login
- `POST /login` — autenticação

Rotas administrativas (apenas usuário logado/admin):

- `GET /admin` — dashboard
- `GET /admin/noticias`
- `GET /admin/noticias/nova`
- `POST /admin/noticias`
- `GET /admin/noticias/:id/editar`
- `POST /admin/noticias/:id`
- `POST /admin/noticias/:id/deletar`

---

## Comandos úteis

- `npm install` — instala dependências
- `npm run seed` — cria tabelas e insere dados de exemplo
- `npm run dev` — executa em modo dev com `nodemon`
- `npm start` — inicia com `node app.js`

## Contribuindo

Contribuições são bem-vindas. Passos sugeridos:

1. Fork
2. Crie uma branch `feature/descricao`
3. Commit e push
4. Abra PR

Pequenas melhorias possíveis: adicionar upload de imagens, paginação, API REST JSON, testes automatizados.
